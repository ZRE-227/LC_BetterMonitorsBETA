## INFO
This "mod" is a bundle of client-sided Qol mods for personal use (none made by me please check out the originals)

## CREDITS
Zaggy1024 for OpenBodyCams *https://thunderstore.io/c/lethal-company/p/Zaggy1024/OpenBodyCams/* 

JulianMods for OpenMonitors *https://thunderstore.io/c/lethal-company/p/JulianMods/OpenMonitors/*   

Drakorle for MoreItems *https://thunderstore.io/c/lethal-company/p/Drakorle/MoreItems/* 

Zaggy1024 for PathfindingLagFix *https://thunderstore.io/c/lethal-company/p/Zaggy1024/PathfindingLagFix/*   

ViViKo for ItemClippingFix *https://thunderstore.io/c/lethal-company/p/ViViKo/ItemClippingFix/* 

Lauriican for FriendPatches *https://thunderstore.io/c/lethal-company/p/Lauriichan/FriendPatches/*  

