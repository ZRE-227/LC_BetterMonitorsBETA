## v2.0.0
-added more client-side Qol mods (list in README)

## v1.0.5
-added GoAwayModsList for QoL

## v1.0.0
-might update if current versions get to be too outdated